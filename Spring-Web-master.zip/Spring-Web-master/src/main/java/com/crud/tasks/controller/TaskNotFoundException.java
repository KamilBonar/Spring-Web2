package com.crud.tasks.controller;

public class TaskNotFoundException extends Exception {
}