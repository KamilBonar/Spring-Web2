package com.crud.tasks.domain;

import lombok.Data;

@Data
public class TrelloBoardDto {
    private String name;
    private String id;
}